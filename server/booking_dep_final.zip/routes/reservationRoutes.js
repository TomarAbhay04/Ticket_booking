import express from 'express';
import { createReservation, getAllReservations, getReservationsByUserId } from '../controllers/reservationController.js';

const router = express.Router();

router.post('/', createReservation);
router.get('/', getAllReservations);
router.get('/user/:userId', getReservationsByUserId);

export default router;
